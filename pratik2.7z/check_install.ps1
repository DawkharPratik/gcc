# Check if curl is installed
if (-not (Test-Path -Path "C:\Program Files\curl\curl.exe" -PathType Leaf)) {
    # Install curl using Chocolatey
    Write-Host "curl is not installed. Installing..."
    choco install curl -y
}

# Check if 7-Zip is installed
if (-not (Test-Path -Path "C:\Program Files\7-Zip\7z.exe" -PathType Leaf)) {
    # Install 7-Zip using Chocolatey
    Write-Host "7-Zip is not installed. Installing..."
    choco install 7zip -y
}

# Check and display installation status
if (Test-Path -Path "C:\Program Files\curl\curl.exe" -PathType Leaf) {
    Write-Host "curl is installed."
}
if (Test-Path -Path "C:\Program Files\7-Zip\7z.exe" -PathType Leaf) {
    Write-Host "7-Zip is installed."
}
