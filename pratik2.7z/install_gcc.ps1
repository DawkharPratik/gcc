# Function to check and install a program using Chocolatey
function Install-Program($programName) {
    if (-not (Get-Command $programName -ErrorAction SilentlyContinue)) {
        Write-Host "$programName is not installed. Installing..."
        choco install $programName -y
    } else {
        Write-Host "$programName is already installed."
    }
}

# Check and install curl and 7-Zip using Chocolatey
Install-Program "curl"
Install-Program "7zip"

# Install GCC using MinGW-w64
Write-Host "Installing GCC using MinGW-w64..."
$installDir = "C:\MinGW-w64"
$gccUrl = "https://github.com/jmeubank/tdm-gcc/releases/download/v10.3.0-tdm64-2/mingw64-c-10.3.0-mingw-w64-8.1.0-tdm-64-dwarf.7z"
$gccArchive = Join-Path $installDir "gcc.7z"
$extractPath = Join-Path $installDir "mingw64"
curl -L -o $gccArchive $gccUrl
7z x $gccArchive -o$installDir
Remove-Item -Path $gccArchive
$envPath = [System.Environment]::GetEnvironmentVariable("Path", [System.EnvironmentVariableTarget]::Machine)
if (-not ($envPath -like "*$installDir\mingw64\bin*")) {
    [System.Environment]::SetEnvironmentVariable("Path", "$envPath;$installDir\mingw64\bin", [System.EnvironmentVariableTarget]::Machine)
    Write-Host "GCC has been added to the system PATH."
} else {
    Write-Host "GCC is already added to the system PATH."
}

# Verify GCC installation
if (Test-Path -Path "$installDir\mingw64\bin\gcc.exe" -PathType Leaf) {
    Write-Host "GCC has been successfully installed."
} else {
    Write-Host "Error: GCC installation failed."
}
